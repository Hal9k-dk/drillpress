<?php
/**
 * Page not found.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="content" class="aluleth-main">
	<section class="aluleth-container aluleth-container--narrow aluleth-404">
		<p class="aluleth-404__code" aria-hidden="true">404</p>
		<h1 class="aluleth-404__title"><?php esc_html_e( 'This page could not be found', 'aluleth' ); ?></h1>
		<p><?php esc_html_e( 'The link may be broken or the page may have moved. Try a search or go back to the home page.', 'aluleth' ); ?></p>
		<?php get_search_form(); ?>
		<p><a class="aluleth-button" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to home', 'aluleth' ); ?></a></p>
	</section>
</main>
<?php
get_footer();
