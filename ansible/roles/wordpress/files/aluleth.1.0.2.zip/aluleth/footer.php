<?php
/**
 * The footer.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

aluleth_site_footer();
?>
</div><!-- #page -->
<?php wp_footer(); ?>
</body>
</html>
