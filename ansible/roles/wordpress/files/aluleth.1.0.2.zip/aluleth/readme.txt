=== Aluleth ===
Contributors: aluleth
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A fast, lightweight theme for Elementor. Use any Elementor template as your header or footer, even with free Elementor.

== Description ==

Aluleth is a lightweight starter theme made for Elementor.

* **Header and footer from any Elementor template**, with the free version of Elementor. Save a section or container as a template, then pick it in Appearance > Customize > Aluleth options. Elementor Pro Theme Builder templates are supported too and always take priority.
* **Built-in header and footer** when you do not need a template: logo, site title and tagline (each can be hidden in Appearance > Customize > Site Identity), menu, call-to-action button, colors, copyright text.
* **Sticky and transparent header**, for the home page only or for every page.
* **Page templates**: Full width (header and footer, no title) and Blank canvas (no header, no footer). Page breaks and comments work with every template, including pages built with Elementor.
* Previous and next post links under each post, and a "Read more" link on every post in the blog.
* Pages built with Elementor are shown full width automatically, and Elementor's "Hide title" setting works.
* Mobile menu without jQuery, skip link, visible focus and keyboard-friendly dropdowns.
* No external requests: no fonts or scripts loaded from other servers.

All settings are in Appearance > Customize > Aluleth options.

== Frequently Asked Questions ==

= Do I need Elementor? =

No. The theme works on its own with the block editor. Elementor is recommended to design pages, headers and footers visually.

= How do I use an Elementor template as my header? =

In Elementor, go to Templates > Saved Templates and create a section, container or page template for your header. Then open Appearance > Customize > Aluleth options > Header, choose "Elementor template" and select your template. Do the same for the footer.

= Can I remove the "Built with Aluleth" credit? =

Yes. Untick it in Appearance > Customize > Aluleth options > Footer.

= Does the theme collect any data? =

No. Aluleth does not track visitors or users and does not contact any external service.

== Changelog ==

= 1.0.2 =
* Long titles and long words (site title, post and page titles, lists, post navigation, footer) wrap inside the screen instead of making it scroll sideways.
* New screenshot with placeholder text.
* Styles and scripts load with the theme version, so browsers pick up new files after an update.

= 1.0.1 =
* The built-in header shows the site title and the tagline next to the logo. Both can be hidden in Appearance > Customize > Site Identity, and the Customizer preview updates as you type.
* Blank canvas: page links for content split with the Page Break block, and comments under the content.
* Comments now show with the Full width template and on pages built with Elementor.
* Previous and next post navigation on single posts.
* Blog lists: a "Read more" link on every post, and "(No title)" for posts without a title.
* New screenshot: a capture of the theme on a demo site.

= 1.0.0 =
* First release.

== Upgrade Notice ==

= 1.0.2 =
Long titles no longer make the page scroll sideways on phones.

= 1.0.1 =
The site title and tagline now show next to the logo (you can hide them in Site Identity), plus comments and page links in every layout.

= 1.0.0 =
First release.

== Copyright ==

Aluleth WordPress Theme, (C) 2026 Aluleth Corp LLC.
Aluleth is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Resources ==

* All code, styles and icons in this theme are original work by Aluleth Corp LLC, licensed under GPLv2 or later.
* Screenshot: a browser capture of the theme on a demo site with placeholder text (Lorem ipsum). The placeholder logo (a circle in a square) was made by Aluleth Corp LLC for the capture. Licensed under GPLv2 or later.
