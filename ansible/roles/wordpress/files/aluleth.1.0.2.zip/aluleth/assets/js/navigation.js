/**
 * Aluleth: mobile menu and header state. No jQuery.
 *
 * - The toggle button opens and closes the menu (aria-expanded is kept in sync).
 * - Escape closes the menu and gives focus back to the toggle.
 * - The menu closes when a link inside it is followed or when the window
 *   becomes wide enough for the desktop menu.
 * - The header gets the class "is-scrolled" once the page is scrolled,
 *   used by the sticky and transparent header styles.
 */
( function () {
	'use strict';

	var header = document.getElementById( 'site-header' );

	if ( ! header ) {
		return;
	}

	var toggle = header.querySelector( '.aluleth-menu-toggle' );
	var desktop = window.matchMedia( '(min-width: 922px)' );

	function setOpen( open ) {
		if ( ! toggle ) {
			return;
		}
		header.classList.toggle( 'is-open', open );
		toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
	}

	if ( toggle ) {
		toggle.addEventListener( 'click', function () {
			setOpen( toggle.getAttribute( 'aria-expanded' ) !== 'true' );
		} );

		header.addEventListener( 'keydown', function ( event ) {
			if ( event.key === 'Escape' && header.classList.contains( 'is-open' ) ) {
				setOpen( false );
				toggle.focus();
			}
		} );

		header.addEventListener( 'click', function ( event ) {
			if ( event.target.closest( '.aluleth-header__nav a' ) && ! desktop.matches ) {
				setOpen( false );
			}
		} );

		var onChange = function ( event ) {
			if ( event.matches ) {
				setOpen( false );
			}
		};

		if ( desktop.addEventListener ) {
			desktop.addEventListener( 'change', onChange );
		} else if ( desktop.addListener ) {
			desktop.addListener( onChange );
		}
	}

	var ticking = false;

	function updateScrolled() {
		header.classList.toggle( 'is-scrolled', window.scrollY > 8 );
		ticking = false;
	}

	window.addEventListener(
		'scroll',
		function () {
			if ( ! ticking ) {
				ticking = true;
				window.requestAnimationFrame( updateScrolled );
			}
		},
		{ passive: true }
	);

	updateScrolled();
}() );
