<?php
/**
 * Comments.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

if ( post_password_required() ) {
	return;
}
?>
<section id="comments" class="aluleth-comments">
	<?php if ( have_comments() ) : ?>
		<h2 class="aluleth-comments__title">
			<?php
			$aluleth_count = get_comments_number();
			printf(
				/* translators: %s: number of comments. */
				esc_html( _n( '%s comment', '%s comments', $aluleth_count, 'aluleth' ) ),
				esc_html( number_format_i18n( $aluleth_count ) )
			);
			?>
		</h2>

		<ol class="aluleth-comments__list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 48,
				)
			);
			?>
		</ol>

		<?php the_comments_navigation(); ?>

		<?php if ( ! comments_open() ) : ?>
			<p class="aluleth-comments__closed"><?php esc_html_e( 'Comments are closed.', 'aluleth' ); ?></p>
		<?php endif; ?>
	<?php endif; ?>

	<?php comment_form(); ?>
</section>
