<?php
/**
 * A single post or page.
 *
 * Pages built with Elementor are printed full width, without the theme
 * container, so Elementor controls the whole layout.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

$aluleth_full = aluleth_is_full_width() || aluleth_is_built_with_elementor();
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $aluleth_full ? 'aluleth-entry aluleth-entry--full' : 'aluleth-entry' ); ?>>
	<?php if ( aluleth_show_title() ) : ?>
		<header class="aluleth-entry__header aluleth-container aluleth-container--narrow">
			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
			<?php aluleth_post_meta(); ?>
		</header>
	<?php endif; ?>

	<?php if ( ! $aluleth_full && has_post_thumbnail() && ! post_password_required() ) : ?>
		<figure class="aluleth-entry__thumbnail aluleth-container aluleth-container--narrow">
			<?php the_post_thumbnail( 'large' ); ?>
		</figure>
	<?php endif; ?>

	<div class="<?php echo esc_attr( $aluleth_full ? 'entry-content' : 'entry-content aluleth-container aluleth-container--narrow' ); ?>">
		<?php
		the_content();

		wp_link_pages(
			array(
				'before' => '<nav class="aluleth-page-links" aria-label="' . esc_attr__( 'Page', 'aluleth' ) . '">',
				'after'  => '</nav>',
			)
		);
		?>
	</div>

	<?php
	$aluleth_is_post      = 'post' === get_post_type();
	$aluleth_has_comments = comments_open() || get_comments_number();
	$aluleth_has_tags     = $aluleth_is_post && ! $aluleth_full && has_tag();
	?>
	<?php if ( $aluleth_is_post || $aluleth_has_comments || $aluleth_has_tags ) : ?>
		<footer class="aluleth-entry__footer aluleth-container aluleth-container--narrow">
			<?php
			if ( $aluleth_has_tags ) {
				the_tags( '<p class="aluleth-entry__tags">', ', ', '</p>' );
			}

			if ( $aluleth_is_post && is_singular( 'post' ) ) {
				the_post_navigation(
					array(
						'prev_text'          => '<span class="aluleth-post-nav__label">' . esc_html__( 'Previous', 'aluleth' ) . '</span> <span class="aluleth-post-nav__title">%title</span>',
						'next_text'          => '<span class="aluleth-post-nav__label">' . esc_html__( 'Next', 'aluleth' ) . '</span> <span class="aluleth-post-nav__title">%title</span>',
						'screen_reader_text' => esc_html__( 'Post navigation', 'aluleth' ),
						'class'              => 'aluleth-post-nav',
					)
				);
			}

			// Comments show with every layout: default, Full width and Elementor.
			if ( $aluleth_has_comments ) {
				comments_template();
			}
			?>
		</footer>
	<?php endif; ?>
</article>
