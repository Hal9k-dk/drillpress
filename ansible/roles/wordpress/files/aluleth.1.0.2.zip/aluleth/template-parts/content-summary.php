<?php
/**
 * A post in a list.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'aluleth-summary' ); ?>>
	<?php if ( has_post_thumbnail() && ! post_password_required() ) : ?>
		<a class="aluleth-summary__thumbnail" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
			<?php the_post_thumbnail( 'medium_large' ); ?>
		</a>
	<?php endif; ?>

	<div class="aluleth-summary__body">
		<?php
		if ( is_sticky() && is_home() && ! is_paged() ) {
			echo '<p class="aluleth-summary__sticky">' . esc_html__( 'Featured', 'aluleth' ) . '</p>';
		}

		$aluleth_title = get_the_title();
		if ( '' === trim( wp_strip_all_tags( $aluleth_title ) ) ) {
			$aluleth_title = esc_html__( '(No title)', 'aluleth' );
		}
		printf(
			'<h2 class="aluleth-summary__title"><a href="%1$s">%2$s</a></h2>',
			esc_url( get_permalink() ),
			wp_kses_post( $aluleth_title )
		);
		aluleth_post_meta();
		?>
		<div class="aluleth-summary__excerpt"><?php the_excerpt(); ?></div>
		<p class="aluleth-summary__more">
			<a href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read more', 'aluleth' ); ?><span class="screen-reader-text"> <?php echo esc_html( wp_strip_all_tags( $aluleth_title ) ); ?></span></a>
		</p>
	</div>
</article>
