<?php
/**
 * Built-in header: logo, menu and call-to-action button.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

$aluleth_cta_text = aluleth_get_option( 'header_cta_text' );
$aluleth_cta_url  = aluleth_get_option( 'header_cta_url' );
$aluleth_has_menu = has_nav_menu( 'primary' );
?>
<div class="aluleth-container aluleth-header__inner">
	<div class="aluleth-header__brand">
		<?php aluleth_site_branding(); ?>
	</div>

	<?php if ( $aluleth_has_menu ) : ?>
		<button class="aluleth-menu-toggle" type="button" aria-controls="aluleth-primary-nav" aria-expanded="false">
			<span class="aluleth-menu-toggle__icon" aria-hidden="true"><span></span><span></span><span></span></span>
			<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'aluleth' ); ?></span>
		</button>
	<?php endif; ?>

	<div id="aluleth-primary-nav" class="aluleth-header__nav">
		<?php if ( $aluleth_has_menu ) : ?>
			<nav class="aluleth-nav" aria-label="<?php esc_attr_e( 'Main menu', 'aluleth' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'aluleth-nav__list',
						'depth'          => 3,
						'fallback_cb'    => false,
					)
				);
				?>
			</nav>
		<?php endif; ?>

		<?php if ( $aluleth_cta_text && $aluleth_cta_url ) : ?>
			<a class="aluleth-button aluleth-header__cta" href="<?php echo esc_url( $aluleth_cta_url ); ?>"><?php echo esc_html( $aluleth_cta_text ); ?></a>
		<?php endif; ?>
	</div>
</div>
