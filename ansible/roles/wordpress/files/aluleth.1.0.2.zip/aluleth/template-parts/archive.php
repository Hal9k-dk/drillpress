<?php
/**
 * Lists of posts: blog, archives and search results.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="aluleth-container aluleth-container--narrow aluleth-archive">
	<?php if ( is_home() && ! is_front_page() ) : ?>
		<header class="aluleth-archive__header">
			<h1 class="aluleth-archive__title"><?php single_post_title(); ?></h1>
		</header>
	<?php elseif ( is_search() ) : ?>
		<header class="aluleth-archive__header">
			<h1 class="aluleth-archive__title">
				<?php
				printf(
					/* translators: %s: search query. */
					esc_html__( 'Search results for: %s', 'aluleth' ),
					'<span>' . esc_html( get_search_query() ) . '</span>'
				);
				?>
			</h1>
		</header>
	<?php elseif ( is_archive() ) : ?>
		<header class="aluleth-archive__header">
			<?php the_archive_title( '<h1 class="aluleth-archive__title">', '</h1>' ); ?>
			<?php the_archive_description( '<div class="aluleth-archive__description">', '</div>' ); ?>
		</header>
	<?php endif; ?>

	<?php if ( have_posts() ) : ?>
		<div class="aluleth-post-list">
			<?php
			while ( have_posts() ) {
				the_post();
				get_template_part( 'template-parts/content', 'summary' );
			}
			?>
		</div>
		<?php
		the_posts_pagination(
			array(
				'prev_text' => esc_html__( 'Previous', 'aluleth' ),
				'next_text' => esc_html__( 'Next', 'aluleth' ),
			)
		);
		?>
	<?php else : ?>
		<?php get_template_part( 'template-parts/content', 'none' ); ?>
	<?php endif; ?>
</div>
