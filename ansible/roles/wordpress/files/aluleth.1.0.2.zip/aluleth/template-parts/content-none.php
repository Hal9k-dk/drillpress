<?php
/**
 * Message when there is nothing to show.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="aluleth-none">
	<?php if ( is_search() ) : ?>
		<p><?php esc_html_e( 'Nothing matched your search. Try other words.', 'aluleth' ); ?></p>
		<?php get_search_form(); ?>
	<?php else : ?>
		<p><?php esc_html_e( 'Nothing has been published here yet.', 'aluleth' ); ?></p>
	<?php endif; ?>
</section>
