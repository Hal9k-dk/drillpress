<?php
/**
 * Built-in footer: menu, copyright and theme credit.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="aluleth-container aluleth-footer__inner">
	<?php if ( has_nav_menu( 'footer' ) ) : ?>
		<nav class="aluleth-footer__nav" aria-label="<?php esc_attr_e( 'Footer menu', 'aluleth' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'footer',
					'container'      => false,
					'menu_class'     => 'aluleth-footer__list',
					'depth'          => 1,
					'fallback_cb'    => false,
				)
			);
			?>
		</nav>
	<?php endif; ?>

	<div class="aluleth-footer__bottom">
		<p class="aluleth-footer__copyright"><?php aluleth_footer_copyright(); ?></p>

		<?php if ( aluleth_get_option( 'footer_credit' ) ) : ?>
			<p class="aluleth-footer__credit">
				<?php
				printf(
					/* translators: %s: theme name with a link to the theme author. */
					esc_html__( 'Built with %s', 'aluleth' ),
					'<a href="' . esc_url( 'https://alulethmarketing.com/' ) . '">' . esc_html__( 'Aluleth', 'aluleth' ) . '</a>'
				);
				?>
			</p>
		<?php endif; ?>
	</div>
</div>
