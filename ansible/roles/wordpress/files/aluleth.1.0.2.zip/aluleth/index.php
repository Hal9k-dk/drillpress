<?php
/**
 * The main template: posts, pages, archives and search results.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="content" class="aluleth-main">
	<?php
	if ( is_singular() ) {
		while ( have_posts() ) {
			the_post();
			get_template_part( 'template-parts/content', 'singular' );
		}
	} else {
		get_template_part( 'template-parts/archive' );
	}
	?>
</main>
<?php
get_footer();
