<?php
/**
 * Aluleth functions and definitions.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

define( 'ALULETH_VERSION', '1.0.2' );
define( 'ALULETH_DIR', get_template_directory() );
define( 'ALULETH_URI', get_template_directory_uri() );

require ALULETH_DIR . '/inc/options.php';
require ALULETH_DIR . '/inc/setup.php';
require ALULETH_DIR . '/inc/template-tags.php';
require ALULETH_DIR . '/inc/elementor.php';
require ALULETH_DIR . '/inc/customizer.php';

if ( is_admin() ) {
	require ALULETH_DIR . '/inc/admin.php';
}
