<?php
/**
 * Theme setup, assets and body classes.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register theme supports and menus.
 */
function aluleth_setup() {
	load_theme_textdomain( 'aluleth', ALULETH_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 80,
			'width'       => 240,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);
	add_theme_support(
		'custom-background',
		array(
			'default-color' => 'ffffff',
		)
	);
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/editor-style.css' );

	register_nav_menus(
		array(
			'primary' => esc_html__( 'Header menu', 'aluleth' ),
			'footer'  => esc_html__( 'Footer menu', 'aluleth' ),
		)
	);
}
add_action( 'after_setup_theme', 'aluleth_setup' );

/**
 * Content width for embeds and images.
 */
function aluleth_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'aluleth_content_width', 800 );
}
add_action( 'after_setup_theme', 'aluleth_content_width', 0 );

/**
 * Front-end styles and scripts.
 */
function aluleth_enqueue_assets() {
	wp_enqueue_style( 'aluleth-reset', get_stylesheet_uri(), array(), ALULETH_VERSION );
	wp_enqueue_style( 'aluleth-theme', ALULETH_URI . '/assets/css/theme.css', array( 'aluleth-reset' ), ALULETH_VERSION );
	wp_add_inline_style( 'aluleth-theme', aluleth_inline_css() );

	if ( 'none' !== aluleth_get_option( 'header_source' ) && ! aluleth_is_canvas() ) {
		wp_enqueue_script(
			'aluleth-navigation',
			ALULETH_URI . '/assets/js/navigation.js',
			array(),
			ALULETH_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
	}

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'aluleth_enqueue_assets' );

/**
 * Replace the "no-js" class on <html> with "js" as early as possible.
 * Without JavaScript the mobile menu simply stays open.
 */
function aluleth_js_class() {
	wp_print_inline_script_tag( "document.documentElement.className=document.documentElement.className.replace('no-js','js');" );
}
add_action( 'wp_head', 'aluleth_js_class', 0 );

/**
 * CSS custom properties built from the Customizer settings.
 *
 * @return string
 */
function aluleth_inline_css() {
	$vars = array(
		'--aluleth-container'   => absint( aluleth_get_option( 'container_width' ) ) . 'px',
		'--aluleth-accent'      => sanitize_hex_color( aluleth_get_option( 'accent_color' ) ),
		'--aluleth-header-bg'   => sanitize_hex_color( aluleth_get_option( 'header_bg' ) ),
		'--aluleth-header-text' => sanitize_hex_color( aluleth_get_option( 'header_text' ) ),
		'--aluleth-header-over' => sanitize_hex_color( aluleth_get_option( 'header_over_text' ) ),
		'--aluleth-footer-bg'   => sanitize_hex_color( aluleth_get_option( 'footer_bg' ) ),
		'--aluleth-footer-text' => sanitize_hex_color( aluleth_get_option( 'footer_text' ) ),
	);

	$css = '';
	foreach ( $vars as $name => $value ) {
		if ( $value && '0px' !== $value ) {
			$css .= $name . ':' . $value . ';';
		}
	}

	return $css ? ':root{' . $css . '}' : '';
}

/**
 * Is the current page using the blank canvas template?
 *
 * @return bool
 */
function aluleth_is_canvas() {
	return is_singular() && 'templates/canvas.php' === get_page_template_slug( get_queried_object_id() );
}

/**
 * Is the current page using the full-width template?
 *
 * @return bool
 */
function aluleth_is_full_width() {
	return is_singular() && 'templates/full-width.php' === get_page_template_slug( get_queried_object_id() );
}

/**
 * Should the header be transparent on this page?
 *
 * @return bool
 */
function aluleth_header_is_transparent() {
	$mode = aluleth_get_option( 'header_transparent' );

	if ( 'all' === $mode ) {
		return true;
	}

	return 'front' === $mode && is_front_page();
}

/**
 * Menu links to a section of a page (for example "/#services") are not the
 * current page: WordPress ignores the "#..." part and would mark them all
 * as current on a one-page site.
 *
 * @param string[] $classes Menu item classes.
 * @param WP_Post  $item    Menu item.
 * @return string[]
 */
function aluleth_anchor_menu_classes( $classes, $item ) {
	if ( isset( $item->url ) && false !== strpos( $item->url, '#' ) ) {
		$classes = array_diff( $classes, array( 'current-menu-item', 'current_page_item' ) );
	}

	return $classes;
}
add_filter( 'nav_menu_css_class', 'aluleth_anchor_menu_classes', 10, 2 );

/**
 * Same rule for aria-current on section links.
 *
 * @param array   $atts Link attributes.
 * @param WP_Post $item Menu item.
 * @return array
 */
function aluleth_anchor_menu_atts( $atts, $item ) {
	if ( isset( $item->url ) && false !== strpos( $item->url, '#' ) ) {
		unset( $atts['aria-current'] );
	}

	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'aluleth_anchor_menu_atts', 10, 2 );

/**
 * Body classes for the layout options.
 *
 * @param array $classes Body classes.
 * @return array
 */
function aluleth_body_classes( $classes ) {
	if ( aluleth_get_option( 'header_sticky' ) ) {
		$classes[] = 'aluleth-has-sticky-header';
	}

	if ( aluleth_header_is_transparent() ) {
		$classes[] = 'aluleth-has-transparent-header';
	}

	if ( aluleth_is_full_width() || aluleth_is_built_with_elementor() ) {
		$classes[] = 'aluleth-full-width';
	}

	return $classes;
}
add_filter( 'body_class', 'aluleth_body_classes' );
