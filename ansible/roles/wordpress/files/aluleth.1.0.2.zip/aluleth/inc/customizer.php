<?php
/**
 * Customizer settings (Appearance > Customize > Aluleth).
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the panel, sections, settings and controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function aluleth_customize_register( $wp_customize ) {
	$wp_customize->add_panel(
		'aluleth',
		array(
			'title'    => esc_html__( 'Aluleth options', 'aluleth' ),
			'priority' => 30,
		)
	);

	$sections = array(
		'aluleth_header' => esc_html__( 'Header', 'aluleth' ),
		'aluleth_footer' => esc_html__( 'Footer', 'aluleth' ),
		'aluleth_layout' => esc_html__( 'Layout and colors', 'aluleth' ),
	);
	foreach ( $sections as $id => $title ) {
		$wp_customize->add_section(
			$id,
			array(
				'title' => $title,
				'panel' => 'aluleth',
			)
		);
	}

	$sources = array(
		'theme'     => esc_html__( 'Built-in', 'aluleth' ),
		'elementor' => esc_html__( 'Elementor template', 'aluleth' ),
		'none'      => esc_html__( 'None', 'aluleth' ),
	);

	$no_elementor_note = aluleth_elementor_active() ? '' : ' ' . esc_html__( 'Install and activate Elementor to use your own templates.', 'aluleth' );

	// Site Identity: site title and tagline in the built-in header.
	aluleth_customize_add(
		$wp_customize,
		'header_show_title',
		'aluleth_sanitize_checkbox',
		array(
			'label'       => esc_html__( 'Display the site title in the header', 'aluleth' ),
			'description' => esc_html__( 'Shown next to the logo when there is one. Applies to the built-in header.', 'aluleth' ),
			'section'     => 'title_tagline',
			'type'        => 'checkbox',
			'priority'    => 11,
		)
	);

	aluleth_customize_add(
		$wp_customize,
		'header_show_tagline',
		'aluleth_sanitize_checkbox',
		array(
			'label'    => esc_html__( 'Display the tagline in the header', 'aluleth' ),
			'section'  => 'title_tagline',
			'type'     => 'checkbox',
			'priority' => 12,
		)
	);

	// Live preview of the logo, site title and tagline.
	foreach ( array( 'blogname', 'blogdescription' ) as $setting ) {
		if ( $wp_customize->get_setting( $setting ) ) {
			$wp_customize->get_setting( $setting )->transport = 'postMessage';
		}
	}
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->remove_partial( 'custom_logo' );
		$wp_customize->selective_refresh->add_partial(
			'aluleth_branding',
			array(
				'selector'            => '.aluleth-header__brand',
				'settings'            => array( 'blogname', 'blogdescription', 'custom_logo', 'aluleth_options[header_show_title]', 'aluleth_options[header_show_tagline]' ),
				'render_callback'     => 'aluleth_site_branding',
				'container_inclusive' => false,
				'fallback_refresh'    => true,
			)
		);
	}

	// Header.
	aluleth_customize_add(
		$wp_customize,
		'header_source',
		'aluleth_sanitize_source',
		array(
			'label'       => esc_html__( 'Header', 'aluleth' ),
			'description' => esc_html__( 'Use the built-in header or any template saved in Elementor > Templates. Elementor Pro Theme Builder headers always take priority.', 'aluleth' ) . $no_elementor_note,
			'section'     => 'aluleth_header',
			'type'        => 'radio',
			'choices'     => $sources,
		)
	);

	aluleth_customize_add(
		$wp_customize,
		'header_template',
		'aluleth_sanitize_template',
		array(
			'label'           => esc_html__( 'Header template', 'aluleth' ),
			'section'         => 'aluleth_header',
			'type'            => 'select',
			'choices'         => aluleth_elementor_template_choices(),
			'active_callback' => 'aluleth_header_uses_elementor',
		)
	);

	aluleth_customize_add(
		$wp_customize,
		'header_sticky',
		'aluleth_sanitize_checkbox',
		array(
			'label'           => esc_html__( 'Sticky header (stays at the top on scroll)', 'aluleth' ),
			'section'         => 'aluleth_header',
			'type'            => 'checkbox',
			'active_callback' => 'aluleth_header_is_shown',
		)
	);

	aluleth_customize_add(
		$wp_customize,
		'header_transparent',
		'aluleth_sanitize_transparent',
		array(
			'label'           => esc_html__( 'Transparent header over the content', 'aluleth' ),
			'section'         => 'aluleth_header',
			'type'            => 'select',
			'choices'         => array(
				'off'   => esc_html__( 'Off', 'aluleth' ),
				'front' => esc_html__( 'Home page only', 'aluleth' ),
				'all'   => esc_html__( 'All pages', 'aluleth' ),
			),
			'active_callback' => 'aluleth_header_is_shown',
		)
	);

	aluleth_customize_color( $wp_customize, 'header_over_text', esc_html__( 'Text color while the header is transparent', 'aluleth' ), 'aluleth_header', 'aluleth_header_can_be_transparent' );

	aluleth_customize_add(
		$wp_customize,
		'header_cta_text',
		'sanitize_text_field',
		array(
			'label'           => esc_html__( 'Button text', 'aluleth' ),
			'description'     => esc_html__( 'Optional button at the end of the menu. Leave empty to hide it.', 'aluleth' ),
			'section'         => 'aluleth_header',
			'type'            => 'text',
			'active_callback' => 'aluleth_header_is_builtin',
		)
	);

	aluleth_customize_add(
		$wp_customize,
		'header_cta_url',
		'esc_url_raw',
		array(
			'label'           => esc_html__( 'Button link', 'aluleth' ),
			'section'         => 'aluleth_header',
			'type'            => 'url',
			'active_callback' => 'aluleth_header_is_builtin',
		)
	);

	aluleth_customize_color( $wp_customize, 'header_bg', esc_html__( 'Header background', 'aluleth' ), 'aluleth_header', 'aluleth_header_is_builtin' );
	aluleth_customize_color( $wp_customize, 'header_text', esc_html__( 'Header text', 'aluleth' ), 'aluleth_header', 'aluleth_header_is_builtin' );

	// Footer.
	aluleth_customize_add(
		$wp_customize,
		'footer_source',
		'aluleth_sanitize_source',
		array(
			'label'       => esc_html__( 'Footer', 'aluleth' ),
			'description' => esc_html__( 'Use the built-in footer or any template saved in Elementor > Templates. Elementor Pro Theme Builder footers always take priority.', 'aluleth' ) . $no_elementor_note,
			'section'     => 'aluleth_footer',
			'type'        => 'radio',
			'choices'     => $sources,
		)
	);

	aluleth_customize_add(
		$wp_customize,
		'footer_template',
		'aluleth_sanitize_template',
		array(
			'label'           => esc_html__( 'Footer template', 'aluleth' ),
			'section'         => 'aluleth_footer',
			'type'            => 'select',
			'choices'         => aluleth_elementor_template_choices(),
			'active_callback' => 'aluleth_footer_uses_elementor',
		)
	);

	aluleth_customize_add(
		$wp_customize,
		'footer_copyright',
		'aluleth_sanitize_inline_html',
		array(
			'label'           => esc_html__( 'Copyright text', 'aluleth' ),
			'description'     => esc_html__( 'Leave empty for "© year site name". Use {year} for the current year. Links, bold and italic are allowed.', 'aluleth' ),
			'section'         => 'aluleth_footer',
			'type'            => 'textarea',
			'active_callback' => 'aluleth_footer_is_builtin',
		)
	);

	aluleth_customize_add(
		$wp_customize,
		'footer_credit',
		'aluleth_sanitize_checkbox',
		array(
			'label'           => esc_html__( 'Show the "Built with Aluleth" credit', 'aluleth' ),
			'section'         => 'aluleth_footer',
			'type'            => 'checkbox',
			'active_callback' => 'aluleth_footer_is_builtin',
		)
	);

	aluleth_customize_color( $wp_customize, 'footer_bg', esc_html__( 'Footer background', 'aluleth' ), 'aluleth_footer', 'aluleth_footer_is_builtin' );
	aluleth_customize_color( $wp_customize, 'footer_text', esc_html__( 'Footer text', 'aluleth' ), 'aluleth_footer', 'aluleth_footer_is_builtin' );

	// Layout and colors.
	aluleth_customize_add(
		$wp_customize,
		'container_width',
		'aluleth_sanitize_width',
		array(
			'label'       => esc_html__( 'Content width (px)', 'aluleth' ),
			'description' => esc_html__( 'Width of the header, footer and archives, between 960 and 1920. Pages built with Elementor use their own width.', 'aluleth' ),
			'section'     => 'aluleth_layout',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => 960,
				'max'  => 1920,
				'step' => 10,
			),
		)
	);

	aluleth_customize_color( $wp_customize, 'accent_color', esc_html__( 'Accent color (links and buttons)', 'aluleth' ), 'aluleth_layout' );

	aluleth_customize_add(
		$wp_customize,
		'show_page_title',
		'aluleth_sanitize_checkbox',
		array(
			'label'       => esc_html__( 'Show the title on pages', 'aluleth' ),
			'description' => esc_html__( 'You can also hide it page by page in Elementor (Page settings > Hide title) or use the Full width template.', 'aluleth' ),
			'section'     => 'aluleth_layout',
			'type'        => 'checkbox',
		)
	);
}
add_action( 'customize_register', 'aluleth_customize_register' );

/**
 * Add one setting and its control.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 * @param string               $key          Option key.
 * @param callable             $sanitize     Sanitize callback.
 * @param array                $control      Control arguments.
 */
function aluleth_customize_add( $wp_customize, $key, $sanitize, $control ) {
	$defaults = aluleth_option_defaults();
	$id       = 'aluleth_options[' . $key . ']';

	$wp_customize->add_setting(
		$id,
		array(
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'default'           => $defaults[ $key ],
			'sanitize_callback' => $sanitize,
		)
	);

	$wp_customize->add_control( $id, $control );
}

/**
 * Add one color setting and its control.
 *
 * @param WP_Customize_Manager $wp_customize    Customizer manager.
 * @param string               $key             Option key.
 * @param string               $label           Control label.
 * @param string               $section         Section ID.
 * @param string               $active_callback Optional active callback.
 */
function aluleth_customize_color( $wp_customize, $key, $label, $section, $active_callback = '' ) {
	$defaults = aluleth_option_defaults();
	$id       = 'aluleth_options[' . $key . ']';

	$wp_customize->add_setting(
		$id,
		array(
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'default'           => $defaults[ $key ],
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$args = array(
		'label'   => $label,
		'section' => $section,
	);
	if ( $active_callback ) {
		$args['active_callback'] = $active_callback;
	}

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, $args ) );
}

/**
 * Active callbacks.
 */

/**
 * Header uses an Elementor template.
 *
 * @return bool
 */
function aluleth_header_uses_elementor() {
	return 'elementor' === aluleth_get_option( 'header_source' );
}

/**
 * Header uses the built-in header.
 *
 * @return bool
 */
function aluleth_header_is_builtin() {
	return 'theme' === aluleth_get_option( 'header_source' );
}

/**
 * A header is shown (built-in or Elementor).
 *
 * @return bool
 */
function aluleth_header_is_shown() {
	return 'none' !== aluleth_get_option( 'header_source' );
}

/**
 * The built-in header can be transparent.
 *
 * @return bool
 */
function aluleth_header_can_be_transparent() {
	return aluleth_header_is_builtin() && 'off' !== aluleth_get_option( 'header_transparent' );
}

/**
 * Footer uses an Elementor template.
 *
 * @return bool
 */
function aluleth_footer_uses_elementor() {
	return 'elementor' === aluleth_get_option( 'footer_source' );
}

/**
 * Footer uses the built-in footer.
 *
 * @return bool
 */
function aluleth_footer_is_builtin() {
	return 'theme' === aluleth_get_option( 'footer_source' );
}

/**
 * Sanitize callbacks.
 */

/**
 * Header or footer source.
 *
 * @param string $value Value.
 * @return string
 */
function aluleth_sanitize_source( $value ) {
	return in_array( $value, array( 'theme', 'elementor', 'none' ), true ) ? $value : 'theme';
}

/**
 * Transparent header mode.
 *
 * @param string $value Value.
 * @return string
 */
function aluleth_sanitize_transparent( $value ) {
	return in_array( $value, array( 'off', 'front', 'all' ), true ) ? $value : 'off';
}

/**
 * Elementor template ID: must be a published Elementor template.
 *
 * @param mixed $value Value.
 * @return int
 */
function aluleth_sanitize_template( $value ) {
	$value = absint( $value );

	if ( $value && 'elementor_library' !== get_post_type( $value ) ) {
		return 0;
	}

	return $value;
}

/**
 * Checkbox.
 *
 * @param mixed $value Value.
 * @return bool
 */
function aluleth_sanitize_checkbox( $value ) {
	return (bool) $value;
}

/**
 * Container width in pixels.
 *
 * @param mixed $value Value.
 * @return int
 */
function aluleth_sanitize_width( $value ) {
	$value = absint( $value );

	return ( $value >= 960 && $value <= 1920 ) ? $value : 1140;
}

/**
 * Footer text with simple inline HTML.
 *
 * @param string $value Value.
 * @return string
 */
function aluleth_sanitize_inline_html( $value ) {
	return wp_kses( (string) $value, aluleth_allowed_inline_html() );
}
