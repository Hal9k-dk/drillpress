<?php
/**
 * Theme options: all settings are stored in one option, `aluleth_options`.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

/**
 * Default value of every theme setting.
 *
 * @return array
 */
function aluleth_option_defaults() {
	return array(
		// Header.
		'header_source'       => 'theme', // theme | elementor | none.
		'header_show_title'   => true, // Site title in the built-in header.
		'header_show_tagline' => true, // Tagline in the built-in header.
		'header_template'     => 0,
		'header_sticky'       => false,
		'header_transparent'  => 'off', // off | front | all.
		'header_over_text'    => '#ffffff', // Text color while the header is transparent.
		'header_cta_text'     => '',
		'header_cta_url'      => '',
		'header_bg'           => '#ffffff',
		'header_text'         => '#16181d',
		// Footer.
		'footer_source'       => 'theme', // theme | elementor | none.
		'footer_template'     => 0,
		'footer_copyright'    => '',
		'footer_credit'       => true,
		'footer_bg'           => '#16181d',
		'footer_text'         => '#e6e8ec',
		// Layout and colors.
		'container_width'     => 1140,
		'accent_color'        => '#2f5bea',
		'show_page_title'     => true,
	);
}

/**
 * Get one theme setting, falling back to its default value.
 *
 * The option is read on every call (WordPress caches it), so the
 * Customizer preview always shows the values being edited.
 *
 * @param string $key Setting key.
 * @return mixed
 */
function aluleth_get_option( $key ) {
	$saved   = get_option( 'aluleth_options', array() );
	$options = wp_parse_args( is_array( $saved ) ? $saved : array(), aluleth_option_defaults() );

	return isset( $options[ $key ] ) ? $options[ $key ] : null;
}
