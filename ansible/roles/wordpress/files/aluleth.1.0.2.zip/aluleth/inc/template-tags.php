<?php
/**
 * Template functions for the header, footer and posts.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

/**
 * Print the site header: Elementor Pro location, Elementor template,
 * built-in header, or nothing.
 */
function aluleth_site_header() {
	if ( aluleth_is_canvas() || aluleth_elementor_pro_location( 'header' ) ) {
		return;
	}

	$source = aluleth_get_option( 'header_source' );

	if ( 'none' === $source ) {
		return;
	}

	$classes = array( 'aluleth-header' );
	if ( aluleth_get_option( 'header_sticky' ) ) {
		$classes[] = 'aluleth-header--sticky';
	}
	if ( aluleth_header_is_transparent() ) {
		$classes[] = 'aluleth-header--transparent';
	}

	if ( 'elementor' === $source ) {
		$classes[] = 'aluleth-header--elementor';
		echo '<header id="site-header" class="' . esc_attr( implode( ' ', $classes ) ) . '">';
		if ( ! aluleth_render_elementor_template( aluleth_get_option( 'header_template' ) ) ) {
			// No valid template: fall back to the built-in header content.
			get_template_part( 'template-parts/header/site-header' );
		}
		echo '</header>';
		return;
	}

	echo '<header id="site-header" class="' . esc_attr( implode( ' ', $classes ) ) . '">';
	get_template_part( 'template-parts/header/site-header' );
	echo '</header>';
}

/**
 * Print the site footer: Elementor Pro location, Elementor template,
 * built-in footer, or nothing.
 */
function aluleth_site_footer() {
	if ( aluleth_is_canvas() || aluleth_elementor_pro_location( 'footer' ) ) {
		return;
	}

	$source = aluleth_get_option( 'footer_source' );

	if ( 'none' === $source ) {
		return;
	}

	if ( 'elementor' === $source ) {
		echo '<footer id="site-footer" class="aluleth-footer aluleth-footer--elementor">';
		if ( ! aluleth_render_elementor_template( aluleth_get_option( 'footer_template' ) ) ) {
			get_template_part( 'template-parts/footer/site-footer' );
		}
		echo '</footer>';
		return;
	}

	echo '<footer id="site-footer" class="aluleth-footer">';
	get_template_part( 'template-parts/footer/site-footer' );
	echo '</footer>';
}

/**
 * Site branding of the built-in header: logo, site title and tagline.
 *
 * The title and the tagline are shown next to the logo; each one can be hidden
 * in Appearance > Customize > Site Identity. With no logo and a hidden title,
 * the title stays for screen readers, so the header keeps its link home.
 */
function aluleth_site_branding() {
	$show_title   = (bool) aluleth_get_option( 'header_show_title' );
	$show_tagline = (bool) aluleth_get_option( 'header_show_tagline' );
	$title        = get_bloginfo( 'name' );
	$tagline      = get_bloginfo( 'description' );
	$tag          = is_front_page() && is_home() ? 'h1' : 'p';

	echo '<div class="aluleth-branding">';

	if ( has_custom_logo() ) {
		the_custom_logo();
	}

	$title_class = $show_title ? 'aluleth-site-title' : ( has_custom_logo() ? '' : 'aluleth-site-title screen-reader-text' );
	$has_tagline = $show_tagline && '' !== trim( $tagline );

	if ( $title_class || $has_tagline ) {
		echo '<div class="aluleth-branding__text">';

		if ( $title_class && '' !== trim( $title ) ) {
			printf(
				'<%1$s class="%2$s"><a href="%3$s" rel="home">%4$s</a></%1$s>',
				tag_escape( $tag ),
				esc_attr( $title_class ),
				esc_url( home_url( '/' ) ),
				esc_html( $title )
			);
		}

		if ( $has_tagline ) {
			echo '<p class="aluleth-site-description">' . esc_html( $tagline ) . '</p>';
		}

		echo '</div>';
	}

	echo '</div>';
}

/**
 * Copyright line of the built-in footer.
 */
function aluleth_footer_copyright() {
	$text = aluleth_get_option( 'footer_copyright' );

	if ( '' === trim( (string) $text ) ) {
		$text = sprintf(
			/* translators: 1: current year, 2: site name. */
			esc_html__( '© %1$s %2$s', 'aluleth' ),
			wp_date( 'Y' ),
			get_bloginfo( 'name' )
		);
	} else {
		$text = str_replace( '{year}', wp_date( 'Y' ), $text );
	}

	echo wp_kses( $text, aluleth_allowed_inline_html() );
}

/**
 * Inline HTML allowed in the footer text.
 *
 * @return array
 */
function aluleth_allowed_inline_html() {
	return array(
		'a'      => array(
			'href'   => true,
			'title'  => true,
			'target' => true,
			'rel'    => true,
		),
		'strong' => array(),
		'em'     => array(),
		'br'     => array(),
		'span'   => array( 'class' => true ),
	);
}

/**
 * Should the title be shown on this singular page?
 *
 * Elementor's "Hide title" page setting also works: it hides
 * `.entry-title`, the class used here.
 *
 * @return bool
 */
function aluleth_show_title() {
	if ( aluleth_is_full_width() ) {
		return false;
	}

	if ( is_page() && ! aluleth_get_option( 'show_page_title' ) ) {
		return false;
	}

	return (bool) apply_filters( 'aluleth_show_title', true );
}

/**
 * Date and author line for posts.
 */
function aluleth_post_meta() {
	if ( 'post' !== get_post_type() ) {
		return;
	}

	$author = get_the_author();

	printf(
		'<p class="aluleth-entry-meta"><time datetime="%1$s">%2$s</time>%3$s</p>',
		esc_attr( get_the_date( DATE_W3C ) ),
		esc_html( get_the_date() ),
		$author ? '<span class="aluleth-entry-meta__sep" aria-hidden="true"> · </span><span class="aluleth-entry-meta__author">' . esc_html( $author ) . '</span>' : ''
	);
}
