<?php
/**
 * Admin: one dismissible notice recommending Elementor.
 *
 * Shown only on the Dashboard and Themes screens, only to users who can
 * install plugins, and never again once dismissed. Nothing is installed
 * automatically: the link opens the WordPress.org plugin search.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

/**
 * Print the notice.
 */
function aluleth_admin_notice() {
	if ( aluleth_elementor_active() || ! current_user_can( 'install_plugins' ) ) {
		return;
	}

	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'themes' ), true ) ) {
		return;
	}

	if ( get_user_meta( get_current_user_id(), 'aluleth_dismissed_elementor_notice', true ) ) {
		return;
	}

	$install_url = admin_url( 'plugin-install.php?s=elementor&tab=search&type=term' );
	$dismiss_url = wp_nonce_url( add_query_arg( 'aluleth-dismiss', 'elementor' ), 'aluleth_dismiss_notice' );
	?>
	<div class="notice notice-info">
		<p>
			<?php esc_html_e( 'Aluleth is made for Elementor. Install the free Elementor plugin to design your pages, header and footer visually.', 'aluleth' ); ?>
		</p>
		<p>
			<a class="button button-primary" href="<?php echo esc_url( $install_url ); ?>"><?php esc_html_e( 'Find Elementor', 'aluleth' ); ?></a>
			<a class="button" href="<?php echo esc_url( $dismiss_url ); ?>"><?php esc_html_e( 'Dismiss', 'aluleth' ); ?></a>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'aluleth_admin_notice' );

/**
 * Save the dismissal for the current user.
 */
function aluleth_dismiss_notice() {
	if ( ! isset( $_GET['aluleth-dismiss'] ) || 'elementor' !== $_GET['aluleth-dismiss'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}

	check_admin_referer( 'aluleth_dismiss_notice' );

	update_user_meta( get_current_user_id(), 'aluleth_dismissed_elementor_notice', 1 );

	wp_safe_redirect( remove_query_arg( array( 'aluleth-dismiss', '_wpnonce' ) ) );
	exit;
}
add_action( 'admin_init', 'aluleth_dismiss_notice' );
