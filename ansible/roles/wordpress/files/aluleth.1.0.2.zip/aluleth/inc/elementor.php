<?php
/**
 * Elementor integration: theme locations and header/footer templates.
 *
 * Works with the free version of Elementor. When Elementor Pro's Theme
 * Builder has a header or footer for the page, it takes priority.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

/**
 * Is Elementor loaded?
 *
 * @return bool
 */
function aluleth_elementor_active() {
	return did_action( 'elementor/loaded' ) && class_exists( '\Elementor\Plugin' );
}

/**
 * Register the core locations for Elementor Pro's Theme Builder.
 *
 * @param \ElementorPro\Modules\ThemeBuilder\Classes\Locations_Manager $manager Locations manager.
 */
function aluleth_register_elementor_locations( $manager ) {
	$manager->register_all_core_location();
}
add_action( 'elementor/theme/register_locations', 'aluleth_register_elementor_locations' );

/**
 * Let Elementor Pro render a location if it has a template for it.
 *
 * @param string $location header or footer.
 * @return bool True when Elementor Pro printed the location.
 */
function aluleth_elementor_pro_location( $location ) {
	return function_exists( 'elementor_theme_do_location' ) && elementor_theme_do_location( $location );
}

/**
 * Is the current singular page built with Elementor?
 *
 * @return bool
 */
function aluleth_is_built_with_elementor() {
	if ( ! aluleth_elementor_active() || ! is_singular() ) {
		return false;
	}

	$document = \Elementor\Plugin::$instance->documents->get( get_queried_object_id() );

	return $document && $document->is_built_with_elementor();
}

/**
 * Respect Elementor's "Hide title" page setting: the title is not printed
 * at all, instead of being hidden with CSS.
 *
 * @param bool $show Show the title.
 * @return bool
 */
function aluleth_elementor_hide_title( $show ) {
	if ( ! $show || ! aluleth_elementor_active() || ! is_singular() ) {
		return $show;
	}

	$document = \Elementor\Plugin::$instance->documents->get( get_queried_object_id() );

	if ( $document && 'yes' === $document->get_settings( 'hide_title' ) ) {
		return false;
	}

	return $show;
}
add_filter( 'aluleth_show_title', 'aluleth_elementor_hide_title' );

/**
 * Elementor templates that can be used as a header or footer.
 *
 * @return array Template ID => title.
 */
function aluleth_elementor_template_choices() {
	$choices = array( 0 => esc_html__( '— Select a template —', 'aluleth' ) );

	if ( ! post_type_exists( 'elementor_library' ) ) {
		return $choices;
	}

	$templates = get_posts(
		array(
			'post_type'      => 'elementor_library',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'     => '_elementor_template_type',
					'value'   => array( 'section', 'container', 'page', 'header', 'footer' ),
					'compare' => 'IN',
				),
			),
		)
	);

	foreach ( $templates as $template ) {
		$choices[ $template->ID ] = $template->post_title ? $template->post_title : sprintf(
			/* translators: %d: template ID. */
			esc_html__( 'Template #%d', 'aluleth' ),
			$template->ID
		);
	}

	return $choices;
}

/**
 * Print an Elementor template chosen in the Customizer.
 *
 * @param int $template_id Template post ID.
 * @return bool True when the template was printed.
 */
function aluleth_render_elementor_template( $template_id ) {
	$template_id = absint( $template_id );

	if ( ! $template_id || ! aluleth_elementor_active() || 'publish' !== get_post_status( $template_id ) ) {
		return false;
	}

	// The template CSS is already enqueued in the <head> (see below).
	$content = \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $template_id, false );

	if ( ! $content ) {
		return false;
	}

	// Elementor builds and escapes this markup itself.
	echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

	return true;
}

/**
 * Load the CSS of the header and footer templates in the <head>,
 * so the page does not flash unstyled content.
 */
function aluleth_enqueue_template_css() {
	if ( ! aluleth_elementor_active() || aluleth_is_canvas() ) {
		return;
	}

	foreach ( array( 'header', 'footer' ) as $part ) {
		if ( 'elementor' !== aluleth_get_option( $part . '_source' ) ) {
			continue;
		}

		$template_id = absint( aluleth_get_option( $part . '_template' ) );

		if ( $template_id && class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
			$css_file = \Elementor\Core\Files\CSS\Post::create( $template_id );
			$css_file->enqueue();
		}
	}
}
add_action( 'wp_enqueue_scripts', 'aluleth_enqueue_template_css', 20 );
