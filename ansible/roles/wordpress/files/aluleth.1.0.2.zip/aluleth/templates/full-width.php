<?php
/**
 * Template Name: Full width
 * Template Post Type: post, page
 *
 * Header and footer, content full width, no title.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

get_template_part( 'index' );
