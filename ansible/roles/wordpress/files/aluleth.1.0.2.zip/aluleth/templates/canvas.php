<?php
/**
 * Template Name: Blank canvas
 * Template Post Type: post, page
 *
 * No header, no footer, content full width, no title. Page links and
 * comments still show under the content.
 *
 * @package Aluleth
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="content" class="aluleth-main aluleth-main--canvas">
	<?php
	while ( have_posts() ) {
		the_post();
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'aluleth-entry aluleth-entry--full' ); ?>>
			<div class="entry-content">
				<?php
				the_content();

				wp_link_pages(
					array(
						'before' => '<nav class="aluleth-page-links aluleth-container aluleth-container--narrow" aria-label="' . esc_attr__( 'Page', 'aluleth' ) . '">',
						'after'  => '</nav>',
					)
				);
				?>
			</div>

			<?php if ( comments_open() || get_comments_number() ) : ?>
				<footer class="aluleth-entry__footer aluleth-container aluleth-container--narrow">
					<?php comments_template(); ?>
				</footer>
			<?php endif; ?>
		</article>
		<?php
	}
	?>
</main>
<?php
get_footer();
